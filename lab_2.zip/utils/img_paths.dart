const String LOGO_IMG = 'assets/flipcart_logo.svg';
