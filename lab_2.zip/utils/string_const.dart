const String APP_TITLE = 'Start Your Business on Shopsy with 0% commission |Flipcart seller Hub';
const List<String> DROPDOWN_TITLES = [
  'Sell Online',
  'Fees and Commission',
  'Grow',
  'Learn',
  'Shopsy'
];

const List<String> DROPDOWN_VALUE_FOR_SELL_ONLINE = [
  'Create Account',
  'List Product',
  'Storage & Shipping',
  'Receive Payments',
  'Grow Faster',
  'Seller App',
  'Help & Support',
];

const List<String> DROPDOWN_VALUE_FOR_FEES_AND_COMMISSION = [
  'Payment Circle',
  'Fee Type',
  'Calculation Gross Margin',
];

const List<String> DROPDOWN_VALUE_FOR_GROW = [
  'FAssured badge',
  'Insights & Tools',
  'Flipkart Ads',
  'Flipkart Value Services',
  'Shopping Festivals',
  'Service Partners',
];

const List<String> DROPDOWN_VALUE_FOR_LEARN = [
  'FAQs',
  'Seller Success Stories',
  'Seller Blogs',
];
