import '../utils/export.dart';

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: true,
      bottom: true,
      child: Scaffold(
        appBar: AppBar(
          title: SvgPicture.asset(
            LOGO_IMG,
            height: 34,
            width: 46,
          ),
          actions: [
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                
              ],
            )
          ],
          centerTitle: false,
        ),
      ),
    );
  }
}
