#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define SIZE 100

int stack[SIZE];
int top = -1;

bool isEmpty() {
    return top == -1;
}

void push(int val) {
    if (top < SIZE - 1)
        stack[++top] = val;
    else
        printf("Stack overflow\n");
}

int pop() {
    if (isEmpty()){
        printf("Stack is empty\n");
        return -1;
    }
    return stack[top--];
}

int change(int val, int index) {
    int pos = top - index + 1;
    if (pos >= 0 && pos <= top)
        return (stack[pos] = val);
    printf("Invalid index for change\n");
    return -1;
}

int peep(int index) {
    int pos = top - index + 1;
    if (pos >= 0 && pos <= top)
        return stack[pos];
    printf("Invalid index for peep\n");
    return -1;
}

int main() {
    int choice, value, index;

    while (1) {
        printf("\nStack Operations:\n");
        printf("1. Push\n");
        printf("2. Pop\n");
        printf("3. Peep\n");
        printf("4. Change\n");
        printf("5. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to push: ");
                scanf("%d", &value);
                push(value);
                break;
            case 2:
                value = pop();
                if (value != -1)
                    printf("Popped: %d\n", value);
                break;
            case 3:
                printf("Enter index from top to peep (1 = top): ");
                scanf("%d", &index);
                value = peep(index);
                if (value != -1)
                    printf("Value at index %d from top: %d\n", index, value);
                break;
            case 4:
                printf("Enter index from top to change (1 = top): ");
                scanf("%d", &index);
                printf("Enter new value: ");
                scanf("%d", &value);
                if (change(value, index) != -1)
                    printf("Value changed successfully.\n");
                break;
            case 5:
                exit(0);
            default:
                printf("Invalid choice. Try again.\n");
        }
    }

    return 0;
}
